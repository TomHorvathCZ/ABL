#!/sbin/sh
tmp/busybox mount -o remount rw /data
tmp/busybox rm data/system/*.key